# Plan de implementación — MVP 40dB

Orden ejecutable de tareas para llegar de "scaffold vacío" a "MVP funcional". Cada paso tiene **dependencias**, **doc autoritativo**, y **done when** explícito.

> **Cómo usar este doc.** Una IA o un dev puede pedir "implementá paso N" y tener toda la info para hacerlo. Si algo no está claro en este plan, el doc autoritativo del paso (columna "Spec") manda. Si el spec tampoco lo cubre, **pregunta antes de inventar**.

---

## Pre-requisitos

Antes de empezar cualquier paso:

- [ ] Tener `supabase` CLI instalado y proyecto local funcionando (`supabase start` levanta sin errores).
- [ ] `.env` con `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_JWT_SECRET`, `CORS_ORIGINS`. (Ver `backend.md` §8.)
- [ ] Python 3.11+ y `pip install -r requirements.txt`. **Atención:** `requirements.txt` está incompleto (solo `fastapi` y `uvicorn`). El paso 0 lo arregla.

---

## Paso 0 — Bootstrap del entorno

**Dependencias:** ninguna.

**Tareas:**
- Completar `requirements.txt` con todas las dependencias necesarias:
  ```
  fastapi
  uvicorn[standard]
  supabase                  # cliente Python oficial
  paho-mqtt                 # cliente MQTT
  pydantic-settings         # config desde env
  pyjwt[crypto]             # verificación JWT local
  python-ulid               # correlation_id
  ```
- Crear `.env.example` en la raíz, con todas las variables de `backend.md` §8 (valores placeholder, sin secretos).
- Agregar `.env`, `__pycache__/`, `.DS_Store` al `.gitignore` si faltan.
- Verificar que `uvicorn main:app --reload` levanta sin error (sigue siendo hola-mundo).

**Done when:**
- `pip install -r requirements.txt` corre sin errores.
- `.env.example` existe y `.env` está gitignoreado.
- `uvicorn main:app --reload` responde 200 en `GET /`.

---

## Paso 1 — Regenerar migración SQL

**Dependencias:** paso 0.

**Spec:** [`bbdd.md`](./bbdd.md) §12 (plan completo de regeneración, paso a paso).

**Tareas resumidas:**
- Eliminar `supabase/migrations/20260519000000_initial_schema.sql` (versión previa desalineada) y `supabase/seed.sql`.
- Crear migración nueva con `supabase migration new initial_schema`.
- Poblarla siguiendo `bbdd.md` §3, §4, §5.1–5.4, §6 en orden. **Atención específica:**
  - `lectura` con `PARTITION BY RANGE (timestamp_medicion)` + PK compuesta `(id, timestamp_medicion)` (D8 en `bbdd.md` §1, detalle en §3.5).
  - Crear las 8 particiones mensuales (`lectura_2026_05` … `lectura_2026_12`) + `lectura_default` (§3.5.1).
  - `reporte` con `lectura_evidencia_id` + `lectura_evidencia_timestamp` + FK compuesta + `chk_evidencia_pair` (§3.6).
  - RPCs `validar_reporte_ruido_top_n` y `crear_reporte_con_validacion` deben devolver el par id+timestamp (§5.2, §5.3).
- Reescribir `supabase/seed.sql` (`bbdd.md` §8 + §12.1 paso 4). Las lecturas mock deben tener `timestamp_medicion` dentro del rango de alguna partición creada.
- Aplicar local con `supabase db reset` y verificar (`bbdd.md` §12.1 paso 6).

**Done when:**
- `supabase db reset` corre sin errores.
- `\dx` en psql muestra `postgis`.
- `\d+ lectura` muestra `Partition key: RANGE (timestamp_medicion)` y lista las particiones.
- `SELECT tableoid::regclass FROM lectura LIMIT 1` confirma que las filas del seed caen en una partición concreta (no en `lectura_default`).
- `SELECT * FROM validar_reporte_ruido(...)` y `SELECT * FROM crear_reporte_con_validacion(...)` existen y devuelven datos (incluyendo el par id+timestamp).
- `INSERT` duplicado en `lectura` con mismo `(sensor_id, timestamp_medicion)` falla con UNIQUE violation.
- `INSERT INTO reporte` con `lectura_evidencia_id` sin `lectura_evidencia_timestamp` falla por `chk_evidencia_pair`; con par válido funciona.

---

## Paso 2 — Estructura de carpetas (hexagonal lite)

**Dependencias:** paso 0.

**Spec:** [`backend.md`](./backend.md) §3.

**Tareas:**
- Crear las carpetas del layout objetivo bajo `app/`: `api/routes/`, `api/schemas/`, `api/middleware/`, `application/`, `domain/`, `infrastructure/db/`, `infrastructure/mqtt/`, `core/`, `patterns/`.
- Mover/renombrar las carpetas scaffold existentes según la tabla de migración en `backend.md` §3.
- Crear `app/__init__.py` vacíos donde haga falta.
- Crear `app/core/config.py` con `pydantic-settings` cargando todas las vars de `backend.md` §8.
- Crear `app/core/supabase_client.py` singleton inicializado con `service_role_key`.
- Reescribir `app/main.py` con: instancia FastAPI, registro de middleware (correlation_id), registro de exception handlers, `lifespan` que arranque MQTT condicionalmente (paso 6).

**Done when:**
- `uvicorn app.main:app --reload` levanta sin errores.
- `app/core/config.py` falla con mensaje claro si falta una env obligatoria.

---

## Paso 3 — Capa de errores y health checks

**Dependencias:** paso 2.

**Spec:** [`errores.md`](./errores.md) (entero) + [`api.md`](./api.md) §4.1, §4.2.

**Tareas:**
- Crear `app/domain/errors.py` con la jerarquía de `errores.md` §2.
- Crear `app/api/error_handlers.py` con los handlers de `errores.md` §5 (registrarlos en `app/main.py`).
- Crear `app/api/middleware/correlation.py` (`errores.md` §6) y registrarlo.
- Crear `app/api/routes/health.py` con `/health/live` y `/health/ready` (`errores.md` §8).
- Implementar los checks de `/health/ready`: ping Supabase con `SELECT 1`, estado MQTT desde el ingestor, presencia de `JWT_SECRET`.

**Done when:**
- `GET /health/live` responde 200.
- `GET /health/ready` responde 200 si Supabase está vivo, 503 si está caído.
- Lanzar `raise NotFoundError("test")` en un endpoint produce el shape uniforme de `errores.md` §4 con HTTP 404.

---

## Paso 4 — Auth: dependency `current_user`

**Dependencias:** paso 3.

**Spec:** [`auth.md`](./auth.md) §5 + [`errores.md`](./errores.md) §10.

**Tareas:**
- Crear `app/domain/entities.py` con dataclass `Usuario` (campos de `bbdd.md` §3.3).
- Crear `app/domain/ports.py` con `Protocol UsuarioRepository`.
- Crear `app/infrastructure/db/usuario_repo.py` con `SupabaseUsuarioRepository: UsuarioRepository`.
- Crear `app/api/deps.py` con:
  - `bearer = HTTPBearer()`.
  - `current_user(...)` que valida JWT con HS256 + `SUPABASE_JWT_SECRET`, audience `"authenticated"`, carga `usuario` por `sub`, verifica `activo=true`.
  - `current_user_municipal(...)` que requiere `tipo='municipalidad'`.
  - `current_user_municipal_de_comuna(comuna_id)` factory.

**Done when:**
- Un endpoint protegido con `Depends(current_user)` responde 401 sin JWT, 401 con JWT inválido, 200 con JWT válido de un usuario activo.
- 401 con JWT válido pero `usuario.activo = false`.

---

## Paso 5 — Endpoints de reportes (CORE)

**Dependencias:** paso 4.

**Spec:** [`api.md`](./api.md) §4.4–§4.9 + [`backend.md`](./backend.md) §5.1.

**Sub-pasos:**

### 5a. `GET /api/v1/reportes/buscar-evidencia`
- Crear `app/application/buscar_evidencia.py`.
- Crear `app/infrastructure/db/rpc.py` con wrapper para `validar_reporte_ruido`.
- Crear route en `app/api/routes/reportes.py` que invoca el use case.
- Schemas en `app/api/schemas/reporte.py`.

### 5b. `POST /api/v1/reportes`
- Crear `app/application/crear_reporte.py`.
- Wrapper RPC para `crear_reporte_con_validacion` (`bbdd.md` §5.3).
- El use case **solo invoca la RPC y mapea el resultado**. La atomicidad vive en SQL.
- Validar en el use case: `usuario.comuna_id` está seteado (si no, derivar de lat/lng o rechazar — decidir al implementar).

### 5c. `GET /api/v1/reportes/mios` (paginado)
- Use case `listar_reportes_propios` con cursor `(created_at, id)`.
- Encoding del cursor: base64 de JSON con esos dos campos.

### 5d. `GET /api/v1/reportes/comuna/{id}` (paginado, municipal)
- Mismo shape que 5c pero con `current_user_municipal_de_comuna(id)`.

### 5e. `GET /api/v1/reportes/{id}` (detalle)
- Use case `obtener_reporte` con permisos: dueño o municipal de la comuna del reporte.

### 5f. `PATCH /api/v1/reportes/{id}/estado`
- Use case `cambiar_estado_reporte`.
- Validar máquina de estados (`bbdd.md` §7) y comentario obligatorio para `Descartado`.
- Si transición es `En espera → En atencion`, setear `atendido_por_id = current_user.id`.

**Done when:**
- Los 6 endpoints responden los shapes de `api.md` §4.4–§4.9.
- Test manual con `curl` + JWT genuino de Supabase:
  - Crear reporte → 201 con `lectura_evidencia` poblada si hay sensor con lectura alta cerca.
  - Cambiar estado saltando "En atencion" → 409.
  - Funcionario de otra comuna → 403.

---

## Paso 6 — Ingestor MQTT

**Dependencias:** paso 2 (estructura) + paso 1 (DB lista).

**Spec:** [`iot.md`](./iot.md) (entero) + [`backend.md`](./backend.md) §5.2.

**Tareas:**
- Crear `app/infrastructure/mqtt/ingestor.py` con clase `MqttIngestor`:
  - Conexión con TLS (puerto 8883), reconexión con backoff (paho-mqtt nativo).
  - Subscribe a `40db/sensores/+/lectura` con QoS 1.
  - `on_message`: extraer `sensor_id` del topic, parsear JSON, validar payload (`iot.md` §3.2), verificar que `sensor_id` existe (con cache), invocar `registrar_lectura`.
- Crear `app/application/registrar_lectura.py`.
- Crear `app/infrastructure/db/lectura_repo.py` con `INSERT ... ON CONFLICT DO NOTHING`.
- En `app/main.py` `lifespan`: arrancar `MqttIngestor` en `asyncio.create_task(...)` si las vars MQTT existen; logear "MQTT deshabilitado" si no.
- Exponer estado del ingestor para `/health/ready` (paso 3).

**Done when:**
- Si MQTT no configurado, FastAPI levanta y `/health/ready` reporta `mqtt: "disabled"`.
- Con MQTT configurado, publicar un mensaje válido en `40db/sensores/<id-existente>/lectura` resulta en un row en `lectura`.
- Publicar el mismo mensaje 2 veces: solo 1 row (UNIQUE absorbe).
- Publicar payload malformado: `WARNING` en logs, ingestor sigue procesando.

---

## Paso 7 — Heatmap

**Dependencias:** paso 1 + paso 2.

**Spec:** [`api.md`](./api.md) §4.3 + [`bbdd.md`](./bbdd.md) §5.4 + [`backend.md`](./backend.md) §5.3.

**Tareas:**
- Agregar `heatmap()` a `LecturaRepository` que ejecuta la SQL de `bbdd.md` §5.4.
- Crear `app/application/obtener_heatmap.py`.
- Crear route en `app/api/routes/heatmaps.py` con validación de bbox + ventana + bucket.
- Serializar a `FeatureCollection` GeoJSON (`api.md` §4.3).
- Endpoint público (sin `Depends(current_user)`).

**Done when:**
- `GET /api/v1/heatmaps?bbox=...&time_start=...&time_end=...&bucket_minutes=5` devuelve GeoJSON válido.
- Validaciones: 422 con ventana > 7 días, bucket no permitido, bbox malformado.

---

## Paso 8 — Endpoints auxiliares y onboarding

**Dependencias:** paso 4.

**Spec:** [`api.md`](./api.md) §4.10–§4.13.

**Tareas:**
- `GET /api/v1/usuarios/me`.
- `PATCH /api/v1/usuarios/me` (telefono + comuna_id). Validar que `comuna_id` existe.
- `GET /api/v1/comunas` (público).
- `GET /api/v1/tipos-estado` (público).

**Done when:** los 4 endpoints responden el shape de `api.md`.

---

## Paso 9 — Tests mínimos

**Dependencias:** pasos previos según qué se teste.

**Tareas:**
- Setup de `pytest` + `httpx` + `pytest-asyncio`.
- Tests de happy path para `POST /reportes`, `PATCH /reportes/{id}/estado`, `GET /heatmaps`.
- Test de auth: 401 sin token, 403 cross-comuna.
- Test de máquina de estados: salto prohibido → 409.
- Tests de RPCs con `pgTAP` o queries directas (opcional pero recomendado).

**Done when:** `pytest` corre verde con cobertura de happy paths.

---

## Paso 10 — Rol `admin` + bootstrap

**Dependencias:** pasos 1, 4.

**Spec:** [`auth.md`](./auth.md) §6 (matriz actualizada), §8 (bootstrap + endpoint).

**Tareas:**
- Regenerar migración para incluir CHECK extendido en `usuario.tipo` (D9 en `bbdd.md`). Esto implica otro `supabase db reset --linked` cuando se aplique (no en producción real, sin pérdida de data).
- Agregar dependencies `current_user_admin` y `current_user_municipal_o_admin` en `app/api/deps.py`. Reglas en `auth.md` §5.
- Crear `app/application/promover_usuario.py` con validaciones de `auth.md` §8.2 (incluyendo no-self-demote).
- Crear use case `cambiar_activo_usuario` similar.
- Wrapper en `infrastructure/db/usuario_repo.py` para los PATCH.
- **Bootstrap del primer admin:** SQL manual una sola vez tras el reset (ver `auth.md` §8.1). Documentar el UUID resultante.

**Done when:**
- `current_user_admin` rechaza con 403 a ciudadanos y municipales.
- Promoción ciudadano → municipalidad con `comuna_id` válido → 200 + DB refleja cambio.
- Promoción ciudadano → municipalidad sin `comuna_id` → 422.
- Admin intentando degradarse a sí mismo → 422 `cannot_demote_self`.

---

## Paso 11 — Endpoints de sensores (admin/municipalidad)

**Dependencias:** paso 10.

**Spec:** [`api.md`](./api.md) §4.14–§4.19 + [`bbdd.md`](./bbdd.md) §5.5–§5.6.

**Tareas:**
- Agregar RPCs `sensores_con_salud` y `resumen_salud_sensores` a la migración (`bbdd.md` §5.5/§5.6).
- Crear `app/domain/entities.py` `Sensor` (si no existe ya con todos los campos).
- Crear `app/infrastructure/db/sensor_repo.py` con: `listar(comuna_id?, estado_salud?, activo?, cursor, limit)`, `get_by_id(id)`, `resumen(comuna_id?)`, `crear(...)`, `actualizar(id, ...)`, `desactivar(id)`.
- Use cases en `app/application/`: `listar_sensores`, `obtener_resumen_sensores`, `crear_sensor`, `actualizar_sensor`, `desactivar_sensor`. Cada uno aplica regla de comuna según rol.
- Routes en `app/api/routes/sensores.py` con las 6 operaciones de §4.14–§4.19.
- Schemas Pydantic en `app/api/schemas/sensor.py`.

**Done when:**
- `GET /sensores` como admin lista todos los sensores con `estado_salud` correcto (probar con timestamps muy viejos → `offline`, recientes → `online`).
- `GET /sensores` como municipalidad filtra por su comuna.
- `POST /sensores` como admin crea con UUID generado.
- `DELETE /sensores/{id}` setea `activo=false`.

---

## Paso 12 — Endpoints de usuarios (admin)

**Dependencias:** paso 10.

**Spec:** [`api.md`](./api.md) §4.20–§4.22.

**Tareas:**
- Extender `app/infrastructure/db/usuario_repo.py` con `listar(tipo?, comuna_id?, activo?, q?, cursor, limit)`. Hacer JOIN a `auth.users` para traer `email`.
- Use cases `listar_usuarios`, `cambiar_activo_usuario`, `promover_usuario`.
- Routes en `app/api/routes/usuarios.py` (extender el existente).
- Schemas Pydantic en `app/api/schemas/usuario.py`.

**Done when:**
- `GET /usuarios` como admin lista usuarios filtrados.
- `PATCH /usuarios/{id}/promover` con casos de §4.22 (happy path, sin comuna, self-demote, comuna inexistente).
- `PATCH /usuarios/{id}/activo` desactiva, y un GET con el JWT del desactivado devuelve 401.

---

## Paso 13 — Soporte de `comuna_id` en `POST /reportes`

**Dependencias:** paso 5 ya implementó el endpoint base.

**Spec:** [`api.md`](./api.md) §4.5 (body actualizado) + §4.5.1 (resolución cliente).

**Tareas (mínimas, son ~10 líneas):**
- En `app/api/schemas/reporte.py`, agregar `comuna_id: Optional[int]` al `CrearReporteRequest`.
- En `app/application/crear_reporte.py`, lógica: si `comuna_id` viene → validar contra catálogo, usarlo. Si no → fallback a `usuario.comuna_id`. Si ambos `null` → 422.
- Sin cambios en la RPC (sigue tomando `p_comuna_id`).

**Done when:**
- POST con `comuna_id` válido → 201 con `comuna_id` en la respuesta.
- POST con `comuna_id` inexistente → 422.
- POST sin `comuna_id` y usuario con `comuna_id` → 201 usando el del usuario.
- POST sin `comuna_id` y usuario sin `comuna_id` → 422 con mensaje claro.

---

## Paso 14 — Capa de agregación OLAP (rollups horarios + matview heatmap)

**Dependencias:** paso 1 (DB con `lectura` particionada), paso 4 (auth), paso 6 (ingestor MQTT corriendo) y paso 7 (endpoint `/heatmaps` funcionando). Recomendable hacerlo **después de tener al menos algunas horas de lecturas reales o seed** — si la matview se crea sobre cero rows queda válida pero vacía.

**Spec:** [`bbdd.md`](./bbdd.md) §13 + [`api.md`](./api.md) §4.27 + [`backend.md`](./backend.md) ADR 09.

**Motivación.** Componente de **big data lite** del proyecto: agregaciones precomputadas dentro de Postgres para escalar a ~100M rows/año de `lectura` sin agregar infra externa. Cero costo en Supabase free.

**Sub-pasos:**

### 14a. Migración SQL

- Crear migración nueva: `supabase migration new agregacion_olap`.
- Poblar siguiendo [`bbdd.md`](./bbdd.md) §13 en orden:
  - §13.1 `CREATE TABLE lectura_resumen_horaria` + 2 índices.
  - §13.2 `CREATE OR REPLACE FUNCTION refrescar_resumen_horario(...)`.
  - §13.3 `CREATE MATERIALIZED VIEW mv_heatmap_celda_bucket` + UNIQUE index + btree index.
  - §13.4 `CREATE EXTENSION IF NOT EXISTS pg_cron;` + 2 `cron.schedule(...)`.
- **Habilitar `pg_cron` en Supabase Dashboard** (Database → Extensions → pg_cron) si no está activo. La extensión vive en la base `postgres`.
- Hacer una corrida manual antes de confiar en el cron:
  ```sql
  SELECT refrescar_resumen_horario('2026-05-01'::timestamptz);
  REFRESH MATERIALIZED VIEW CONCURRENTLY mv_heatmap_celda_bucket;
  ```

### 14b. Capa hexagonal del nuevo endpoint

- `app/domain/entities.py`: agregar dataclass `ResumenHorario` (`sensor_id`, `hora`, `avg_db`, `min_db`, `max_db`, `p95_db`, `n_lecturas`, `refrescado_at`).
- `app/domain/ports.py`: `Protocol ResumenHorarioRepository` con `listar(sensor_id, desde, hasta) -> list[ResumenHorario]`.
- `app/infrastructure/db/resumen_horario_repo.py`: `SupabaseResumenHorarioRepository` que hace `SELECT … FROM lectura_resumen_horaria WHERE sensor_id=… AND hora >= … AND hora < … ORDER BY hora`.
- `app/application/obtener_resumen_horario.py`: use case que valida ventana ≤ 90 días, verifica que el sensor existe, aplica regla de comuna (municipalidad solo su comuna, admin todas) y arma el DTO.
- `app/api/schemas/lectura.py`: Pydantic schemas request/response del shape de [`api.md`](./api.md) §4.27.
- `app/api/routes/lecturas.py`: route nueva con `Depends(current_user_municipal_o_admin)`.

### 14c. Optimización del endpoint `/heatmaps` para usar la matview

- En `app/infrastructure/db/lectura_repo.py`, dentro de `LecturaRepository.heatmap(...)`:
  - **Si** `bucket_minutes == 5` **y** ambos timestamps están dentro de `now() - interval '7 days'` → `SELECT … FROM mv_heatmap_celda_bucket WHERE lng_cell BETWEEN … AND lat_cell BETWEEN … AND bucket_start BETWEEN …`.
  - **Si no** → `rpc('heatmap_agregado', …)` (camino actual).
- El use case `obtener_heatmap` y el route **no cambian** — la decisión es 100% adapter (hexagonal lite).
- Agregar campo informativo al response: `metadata.fuente ∈ {"matview", "rpc"}` para debug.

### 14d. Verificación operacional

- `SELECT * FROM cron.job;` lista los 2 jobs (`refrescar_resumen_horario`, `refrescar_mv_heatmap`).
- `SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 10;` muestra runs sin errores.
- Provocar una lectura nueva via MQTT, esperar al minuto 5 de la próxima hora, verificar que `lectura_resumen_horaria` tiene una row para ese sensor + hora.
- `EXPLAIN ANALYZE` del query del heatmap con params en ventana matview → confirma `Seq Scan on mv_heatmap_celda_bucket` (o index scan), no `Append … lectura_2026_*`.

**Done when:**
- `GET /api/v1/lecturas/resumen?sensor_id=…&desde=…&hasta=…` devuelve el shape de [`api.md`](./api.md) §4.27.
- Como `municipalidad`, sensor de otra comuna → 403.
- Ventana > 90 días → 422.
- `GET /api/v1/heatmaps` con `bucket_minutes=5` y ventana de 24 h en los últimos 7 días devuelve resultados idénticos al del path RPC (comparar sobre seed data), pero con `metadata.fuente = "matview"`.
- `GET /api/v1/heatmaps` con `bucket_minutes=60` o ventana fuera de los 7 días devuelve `metadata.fuente = "rpc"`.
- Los 2 jobs de `pg_cron` corren al menos una vez sin errores (`cron.job_run_details.status = 'succeeded'`).

---

## Resumen visual de dependencias

```
0. Bootstrap
   │
   ├──▶ 1. Migración SQL ────────┐
   │                              │
   └──▶ 2. Estructura carpetas ───┤
                │                  │
                ▼                  │
         3. Errores + health       │
                │                  │
                ▼                  │
         4. Auth (current_user)    │
                │                  │
                ├──▶ 5. Reportes ◀─┤
                │                  │
                ├──▶ 6. MQTT  ◀────┤
                │                  │
                ├──▶ 7. Heatmap ◀──┘
                │
                └──▶ 8. Auxiliares
                       │
                       ▼
                  9. Tests
```

Pasos 5, 6, 7, 8 son **paralelizables** entre sí una vez completados 1–4.

Pasos 10–13 vienen después y se acoplan así:

```
9. Tests (puede arrancar después de cualquier paso 5+, en paralelo)
   │
10. Rol admin + bootstrap   ◀── requiere 1 (CHECK) y 4 (auth)
    │
    ├──▶ 11. Endpoints sensores (admin/municipal)
    │
    └──▶ 12. Endpoints usuarios (admin)

13. comuna_id en POST /reportes   ◀── independiente, edita lo existente del paso 5

14. Capa OLAP (rollups + matview)  ◀── requiere 1, 4, 6, 7 (todo el pipeline IoT vivo)
```

---

## Excluido del MVP (no implementar)

Aunque aparezcan en roadmap de otros docs, **no** son parte de este plan:

- `validacion_iot` N:M (`bbdd.md` §10.1).
- ~~Vistas materializadas (`bbdd.md` §10.4)~~ — **promovida al MVP en el paso 14** (capa OLAP).
- **Automatización** de creación de particiones con `pg_partman` (`bbdd.md` §10.3). El particionamiento en sí **sí** está en el MVP (paso 1).
- SSE / WebSockets para heatmap "vivo" (`backend.md` §9).
- Endpoint admin de promoción de roles (`auth.md` §12).
- Topics MQTT `status`, `config`, `comandos` (`iot.md` §2.2).
- Rate limiting / Idempotency-Key (`api.md` §1 — API8).
- Observers reactivos que revaliden reportes al llegar lecturas altas (`backend.md` §9, explícitamente rechazado).
- Google OAuth / Magic links / MFA (`auth.md` §12).

Cuando alguno de estos surja como necesidad real, **primero actualizar el doc autoritativo**, después agregar al plan.
